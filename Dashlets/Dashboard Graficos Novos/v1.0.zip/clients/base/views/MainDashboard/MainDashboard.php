<?php

$viewdefs['base']['view']['MainDashboard'] = array(
    'dashlets' => array(
        array(
            'name' => 'Relatórios de atendimentos',
            'label' => 'Relatórios de atendimentos',
            'description' => 'Relatórios de Atendimentos',
            'config' => array(),
            'preview' => array(),
            'filter' => array(
                'module' => array('Home',),
                'view' => ''
            ),
        ),
    ),
);